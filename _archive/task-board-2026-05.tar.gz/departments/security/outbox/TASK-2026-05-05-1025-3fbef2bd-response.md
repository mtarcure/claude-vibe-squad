---
task_id: TASK-2026-05-05-1025-3fbef2bd
specialist: privacy-steward
model: claude
status: PASS
upgrade_recommended: no
worksheet_path: /tmp/cdp_dumps/sweedweb-phase8c-privacy-steward-20260505-172851/privacy-worksheet.md
---

# Phase 8C — Privacy-Steward Cross-Tenant PII / Regulatory Review

Reasoning-only over Phase 4 / 5B / 5C / 5D / 5E / 6E / 7A evidence files cited in the task packet. No probes. Sweed scope brackets are the bracket-of-record; cannabis-industry regulation is narrative amplifier only — Sweed pays per L172–L188, not per CVSS or regulator.

## Per-Sub-Vector Privacy / Regulatory Review

| # | Sub-vector | Direct PII? | Chain to PII? | Cross-tenant boundary signal? | Regulatory frame | Recommended severity |
|---|---|---|---|---|---|---|
| 1 | ApiError envelope (inner-test3 `/SeoFiles/GetSeoFile` 404 JSON: `name`, endpoint, `seoFileType`, `domain`, traceId, RFC URI, `details.body`) | no | none — fields are framework metadata; SeoFiles by definition serves SEO files, not customer data | minimal in isolation; verbosity is server-default not tenancy-aware | none cleanly applies (METRC / BioTrack / HIPAA-state / PCI do not regulate framework error envelopes) | **Low (L185)** |
| 2 | XFH echo — XFH-controlled `request.domain` (Phase 5C confirmed flip; Phase 5E content DENIED, fails closed on substituted tenant + on non-tenant negative control) | no — no tenant content returned in any of the 6 probes (4×5C + 2×5E) | conditional / unconfirmed: requires combining with a future data-bearing endpoint that also accepts spoofed XFH — Phase 7A confirmed `/api/labdata/v1/upload` is 401 auth-gated for anon, closing the obvious anonymous chain; an authed-tenant-A → tenant-B write chain is plausible-but-unprobed | **strongest of the four** — XFH alone (TLS SNI held to inner-test3) flips server-side tenant context to attacker-chosen value; this is a real tenancy-boundary smell even though content was denied | conditional cannabis-state / HIPAA-ish / PCI ONLY if a future probe lands cross-tenant data on a curaleaf medical-flow or cashier payment path — NOT in evidence today | **Low (L185)** — agrees with Phase 5E. Strict reading of L176 ("unauthorized access to data") is not satisfied because Phase 5E denied content. Generous reading could argue Medium capped by inner-test3 L163 asset tier, but the bundle still rolls up at the highest *demonstrated* link per scope L240–L241 |
| 3 | otel header `x-swd-otel-trace-id` (multi-host: inner-test3, store, cashier, labdata cluster — Phase 5B/5D/7A) | no | no — high-entropy hex (per Phase 5B observed entropy across independent calls); not joinable to a person without log access; Phase 4 R-strand traceId-guessing speculation already invalidated | none — trace IDs do not encode tenancy | none meaningfully applies (PCI Req. 10 covers logging integrity not correlation-ID leak; opaque trace IDs are not personal data under GDPR/CCPA absent a join key) | **Low (L185)** — multi-host pattern reinforces the L185 framing |
| 4 | Internal hostnames in JS bundles (8 Sentry DSNs across `sentry.kube.sweedpos.com` + `sentry.kube-prod.sweedpos.com`; PostHog `phc_*` keys + 4 PostHog hosts are public-by-design and NOT findings) | no | weak — DSNs are write-only public client keys (event ingest only, not event read); reading PII from Sentry would require admin auth on the Sentry instance, which is OOS and not enabled by DSN possession | weak — `kube` vs `kube-prod` naming mirrors the Phase 4 Dex split (one dev cluster, three prod clusters) so it reinforces the architecture map but does not flip tenant context | none — internal hostname disclosure is not a regulated event under METRC / BioTrack / PCI / HIPAA-state | **Low (L185)** |

## Cross-Tenancy Boundary Assessment

- Strongest cross-tenant signal across all 4: **sub-vector 2 — the XFH lever flips server-side `request.domain` to attacker-chosen tenant value (Phase 5C `02-H1a..05-H1d` all confirmed)**, even though Phase 5E denied actual content disclosure on the only endpoint reached.
- Does this signal alone (absent confirmed content disclosure) elevate the bracket per scope L176? **No** under the strict plain-language reading of L176 ("Gaining unauthorized access to data or escalating privileges"). Phase 5E proves no tenant data was accessed — the back-end fails closed and the negative control rules out reflection-only behavior. A context flip without content disclosure is best framed as "tenant-impersonation in error envelope," which is exactly the L185 reframe Phase 5E proposed. Argument against elevation: claiming L176 here would be over-claim that Sweed triagers will down-bracket. Argument for flagging as a watch-this-lever: any future finding (even a separately-found one) that lets the same XFH lever influence a data-bearing endpoint *would* become a true L176 (or L178 if PII) at High bracket — the lever is live and worth Sweed's attention even though it does not earn the bracket today.

## Regulatory Notes for Phase 9 Report Draft

- Open with one paragraph of cannabis-POS multi-tenant context: Sweed serves multi-state recreational and medical tenants (curaleaf publicly runs both lines; inner-test3 → `/banana/recreational` redirect from Phase 4 confirms recreational-vs-medical product-split is part of the tenant data model). This frames *why* a tenancy-boundary signal in this codebase matters more than in a generic SaaS.
- Mention the regulatory landscape factually but without claiming any was breached:
  - Cashier hosts are payment-of-record (PCI-DSS relevance).
  - Storefront hosts feed downstream state cannabis-tracking pipelines (METRC / BioTrack relevance).
  - Admin panels carry dispensary-employee identity via Dex `email+profile+groups` scope (state employee-PII relevance).
- Present the four sub-vectors as one bundled Low (L185) Information Disclosure report (per Phase 5E recommendation) — do NOT split into four reports.
- Call out the XFH lever explicitly as the "tenancy-boundary signal" sub-vector, with the honest framing: lever confirmed, content denied. Recommend Sweed treat it as a hardening priority because any future data-bearing endpoint that consumes XFH for tenant routing would convert it to L176/L178 High.
- Call out `/api/labdata/v1/upload` (Phase 7A: 401 auth-gated, `Allow: POST`) as the one authed-only endpoint where this lever could plausibly flip tenant context for an authed user; this is a "Sweed should test internally" recommendation, NOT a claimed finding.
- Hard "do not include" list for the draft:
  - Do NOT claim PII / patient / payment / employee data was disclosed (none was).
  - Do NOT claim cross-tenant content disclosure (Phase 5E denied it).
  - Do NOT name HIPAA without naming the specific medical-cannabis tenant; the XFH lever was tested against `inner-test3` only.
  - Do NOT cite CVSS — Sweed pays per L172–L188 brackets.

## Cross-Reference With Impact-Validator and Skeptic

- Where I disagree with impact-validator's bracketing (posture-only, the impact-validator response file is parallel-running and not yet visible to me): I will accept Medium on sub-vector 2 *individually* if impact-validator argues a "tenant-context confusion" reframe capped by inner-test3 L163 Medium asset tier. I will NOT accept any sub-vector landing at L176 or L178 High. The bundle as a whole rolls up at Low per scope L240–L241 (chains pay highest *demonstrated* link). If impact-validator wants to upgrade beyond Low, they must point to demonstrated content disclosure I missed — and I have not found it across the seven evidence files.
- Where the skeptic's kill paths fail under the privacy lens (posture-only): a skeptic arguing "all four sub-vectors are Best-Practices remarks and unreportable" (scope L192) is wrong on two grounds. (1) The XFH-flip is a real tenant-boundary fact, not a best-practices remark; the back-end accepts a client-supplied tenant identifier and Phase 5C demonstrated it across two distinct tenant values. (2) The multi-host otel-trace-id leak (3+ hosts including the cashier payment-of-record surface) is a programmatic mis-configuration, not a one-off header oversight, and L185 is the explicit scope line for "Information Disclosure via Headers." A skeptic argument that the *bundle* should be killed entirely fails; a skeptic argument that the bundle should not be upgraded beyond Low *succeeds and aligns with my posture*.

- status: PASS
