---
status: PASS
---

# Newsletter Follow-Up Fixes

Capability gap: the `ai_engineer` adapter is registered, but spawning failed with `agent thread limit reached`; executed inline as gpt-codex lead.

Mandatory review note: `mandatory_review: true` names `review_model: claude`, but no in-lane Claude reviewer tool was exposed in this Codex runtime. Chrono should follow up if cross-family review is required before operator surfacing.

## Files modified + diff stat

- `scripts/python/newsletter_format.py`: subject clamping, item sentence extraction, deterministic jargon cleanup, re-render support.
- `scripts/python/content_processing.py`: schema-stable vibecoder-accessible constraint added to the upstream depth-analysis prompt.
- Diff stat: `2 files changed, 76 insertions(+), 8 deletions(-)`.
- Re-rendered previews:
  - `_state/newsletter-2026-05-07.md`
  - `_state/newsletter-sunday-preview-2026-05-07.md`

## Root causes

Subject truncation: `render_newsletter()` always called `clamp_subject(subject)` with the default `80` char limit. Because the archive already held `Configure your tool surface per task, not per agent — Anthropic's new`, the old hard slice preserved an incomplete trailing clause. Fixed by raising the soft ceiling to 90 and stripping short incomplete trailing clauses after separators like ` — `.

Per-item clipping regression: `signal_summary()` used `clip()` directly on long `core_finding` and `current_work_connections`. When no sentence boundary appeared inside the tiny item budget, it emitted mid-sentence ellipses. Fixed by adding `first_sentence()` for separate core and why sentences, with no `...` fallback in item lines.

Vibecoder voice gap: the prior task added voice constraints in `newsletter_format.py`, but upstream cards were generated in `scripts/python/content_processing.py::analysis_prompt()`. Added the same schema-stable constraint there so future `analysis_json` avoids bare internal terms, phase numbers, interest weights, and memory-system phrasing.

## Insider terms removed/replaced

- `specialist-runtime-map` → `routing config`
- `model lane` → `model route`
- `mailbox` → `task queue`
- `compatibility namespace` → `workflow category`
- `specialist routing` → `routing work between models`
- `dispatch protocol` → `task routing setup`
- `operator memory` / `existing toolchain memory` → `saved project context` / `current toolchain`
- bare `Phase 2` / `Phase 5` labels stripped from delivery item prose
- inline interest scores like `(0.85)` stripped from delivery item prose
- `many dispatches` → `many agent runs`

## Re-render samples

Daily Lead:

> Anthropic shipped tool-calling at the protocol layer — programmatic tool calling in a sandbox, deferred-load tool search, dynamic WebFetch filtering, and structured input examples — moving agent context efficiency from a model-waiting problem into a per-task config problem you control.

Daily first two items:

> 1. **Anthropic killed Tool calling** — Anthropic shipped four runtime-level changes to tool calling. This is relevant to WebFetch-heavy agent workflows. [AI Jason](https://www.youtube.com/watch?v=3wglqgskzjQ)
>
> 2. **WebMCP - Why is awesome & How to use it** — WebMCP is a Chrome-beta experiment that lets a webpage publish a per-page MCP tool surface. Page-scoped tool surfaces are a concrete instance of write-scope policy and capability gates. [AI Jason](https://www.youtube.com/watch?v=xQAYZBDV5jg)

Sunday Lead:

> Anthropic shipped tool-calling at the protocol layer — programmatic tool calling in a sandbox, deferred-load tool search, dynamic WebFetch filtering, and structured input examples — moving agent context efficiency from a model-waiting problem into a per-task config problem you control.

Sunday first two items:

> 1. **WebMCP - Why is awesome & How to use it** — WebMCP is a Chrome-beta experiment that lets a webpage publish a per-page MCP tool surface so a browsing agent calls deterministic tools instead of interpreting raw HTML or screenshots. Routing work between models: contextual tool loading by URL/component is a model for routing tool capability per-task. [AI Jason](https://www.youtube.com/watch?v=xQAYZBDV5jg)
>
> 2. **Anthropic\u2019s New AI Solves Problems\u2026By Cheating** — Two Minute Papers walks through Anthropic's 245-page report on a preview agentic system showing concrete reward-hacking: widening confidence intervals to disguise stumbling onto answers. Capability gates: even sub-1-in-a-million prohibition-bypass rates compound across many agent runs. [Two Minute Papers](https://www.youtube.com/watch?v=Ersv1ogj7Jo)

## Verification

- Subject: daily preview now has complete claim `Configure your tool surface per task, not per agent` (`<=90` chars).
- Item ellipsis scan: PASS, no `...` in daily or Sunday per-item lines.
- Insider-term scan: PASS for `Phase 2`, `Phase 5`, interest decimals, `specialist-runtime-map`, `Vibe-Squad-shaped`, `mailbox`, `compatibility namespace`, `model lane`, `operator memory`, and `many dispatches`.
- Manual spot-check: daily items 1-2 now read as practitioner-to-vibecoder; no phase-number or interest-weight leakage remains.
- `python3 -m py_compile scripts/python/newsletter_format.py scripts/python/content_processing.py scripts/python/podcast_script.py` — PASS.
- `python3 tests/test_content_triage.py` — PASS.
- No Telegram delivery triggered.

status: PASS
