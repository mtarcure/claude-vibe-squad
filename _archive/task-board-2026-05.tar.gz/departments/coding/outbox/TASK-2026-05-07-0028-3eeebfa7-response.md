---
status: completed_with_caveat
---

# Newsletter Format Implementation

Capability gap: the `ai_engineer` adapter is registered, but spawning failed with `agent thread limit reached`; executed inline as gpt-codex lead.

Mandatory review note: `mandatory_review: true` names `review_model: claude`, but no in-lane Claude reviewer tool was exposed in this Codex runtime. Chrono should follow up if cross-family review is required before operator surfacing.

## Files modified + diff stat

- `scripts/python/newsletter_format.py`: changed daily cap to 1800, added local/Sunday helpers, archive Lead threading, daily/weekly render branches, recurring decisions, pulse/archive preservation, vibecoder-accessible prompts, and validation helpers.
- `scripts/python/podcast_script.py`: added local/Sunday branch, Sunday weekly prompt/context, vibecoder voice constraints, and 480s Sunday timeout.
- Diff stat for code: `2 files changed, 329 insertions(+), 62 deletions(-)`.
- Generated preview artifacts:
  - `_state/newsletter-2026-05-07.md` (`1738` bytes)
  - `_state/newsletter-archive-2026-05-07.md` (`32497` bytes)
  - `_state/newsletter-sunday-preview-2026-05-07.md` (`2214` bytes)

Input caveat: the raw 2026-05-07 content artifacts were not present (`morning-brief`, `content-synthesis`, `content-triage`, `cross-day`, `improvements`, and blog summaries). To avoid a meaningless no-signal render, I validated the new shape against the available 2026-05-06 signal inputs and saved the requested 2026-05-07 preview files.

## Lead samples

Daily Lead:

> Anthropic shipped tool-calling at the protocol layer — programmatic tool calling in a sandbox, deferred-load tool search, dynamic WebFetch filtering, and structured input examples — moving agent context efficiency from a model-waiting problem into a per-task config problem you control.

Sunday-simulated Lead:

> Anthropic shipped tool-calling at the protocol layer — programmatic tool calling in a sandbox, deferred-load tool search, dynamic WebFetch filtering, and structured input examples — moving agent context efficiency from a model-waiting problem into a per-task config problem you control.

## Subject samples

- Daily: `Configure your tool surface per task, not per agent — Anthropic's new`
- Sunday simulated: `Agent workflows need week-level review gates`

## Must-fix verification

- Archive Lead threaded: delivery rendering now receives `archive_lead_from_body(archive_body)` after Claude archive normalization; it does not re-call Claude or clip `core_finding` for the lead.
- Local date semantics: added `local_date()` / `is_sunday()` using `America/Los_Angeles`; UTC filenames are preserved.
- Fallback preservation: delivery fallback now preserves `Pulse` and `Full archive: ...` suffix.
- Sentence clip: `clip()` uses `.`, `?`, `!`, drops `;`/`:`, and uses the 40% sentence-boundary threshold with word fallback.
- Sunday podcast: weekly branch targets 8-12 minutes / 11K-15K chars / 16K hard cap, includes weekly context, and uses `480s` timeout.

## Roadmap verification

- Lead synthesis and subject prompt tightened with claim-first, operator-framed constraints.
- Section order implemented: Lead → Decisions conditional → Worth your time → Pulse → Archive.
- Daily cap is 1800; Sunday cap is 2400.
- Sunday branch implemented with Week themes, Worth your week, recurring improvements, weekly Pulse.
- Recurring decisions now include `recurrence_count >= 4 and score >= 5`, with de-dupe/cap.
- `telegram_deliver.py` verified unchanged; archive pointer remains literal path text.

## Vibecoder voice spot-check

Clarification applied: system relevance stays. The prompt now says to explain what changes for the reader’s agent setup, model orchestration, review gates, or tool-calling workflow, and to keep major model/platform releases prominent when they change pipeline capability.

Jargon scan on preview files found none of: `Vibe-Squad-shaped`, `specialist-runtime-map`, `compatibility namespace`, `model lane`, `mailbox`, `specialist routing`, `operator's`.

One near-slip from source text, `Specialist routing`, was rewritten in deterministic item summaries as `routing work between models`.

## Tests run

- `python3 -m py_compile scripts/python/newsletter_format.py scripts/python/podcast_script.py scripts/python/telegram_deliver.py` — PASS.
- `pytest -q tests/test_content_triage.py` — BLOCKED: `pytest` executable/module not installed.
- `python3 tests/test_content_triage.py` — PASS (`content triage fixture regression: PASS`).

Validation checks:

- Daily render: `1738` bytes, under 1800-char target envelope.
- Sunday preview: `2214` bytes, under 2400-char Sunday cap.
- Pulse present in both previews.
- Archive pointer present at the end of both previews.
- No Telegram delivery triggered.

status: completed_with_caveat
